#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/times.h>
#include <time.h>


int main() {
	double ticks;
	struct tms tinfo;

	if((ticks = (double) sysconf(_SC_CLK_TCK)) == -1) {
		perror("Failed to determine clock ticks per second.");
	} else if(times(&tinfo) == (clock_t)(-1)) {
		perror("Failed to get time information.");
	}

	time_t  start1, end1;
	double start2, end2;
	double dif1, dif2;

	int i;
	for(i = 0; i < 50; ++i) {
		start1 = clock() / 1000;
		times(&tinfo);
		start2 = tinfo.tms_cstime / ticks;

		system("copydirectory1 root_dir root_dir2");
		
		end1 = clock() / 1000;
		dif1 = difftime (end1, start1);
		times(&tinfo);
		end2 = tinfo.tms_cstime / ticks;
		dif2 = end2 - start2;
		printf("%d\t%f\t%f\n", i, dif1, dif2);

		system("rm -r root_dir2");
	}

	printf("\n\n");

	for(i = 0; i < 50; ++i) {
		start1 = clock() / 1000;
		times(&tinfo);
		start2 = tinfo.tms_cstime / ticks;

		system("copydirectory2 root_dir root_dir2");
		
		end1 = clock() / 1000;
		dif1 = difftime (end1, start1);
		times(&tinfo);
		end2 = tinfo.tms_cstime / ticks;
		dif2 = end2 - start2;
		printf("%d\t%f\t%f\n", i, dif1, dif2);

		system("rm -r root_dir2");
	}

	printf("\n\n");

	for(i = 0; i < 50; ++i) {
		start1 = clock() / 1000;
		times(&tinfo);
		start2 = tinfo.tms_cstime / ticks;

		system("copydirectory3 root_dir root_dir2");
		
		end1 = clock() / 1000;
		dif1 = difftime (end1, start1);
		times(&tinfo);
		end2 = tinfo.tms_cstime / ticks;
		dif2 = end2 - start2;
		printf("%d\t%f\t%f\n", i, dif1, dif2);

		system("rm -r root_dir2");
	}
}
